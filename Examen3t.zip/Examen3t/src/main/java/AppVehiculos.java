import com.mycompany.examen3t.Vehiculo;
import com.mycompany.examen3t.VelocidadInvalidaException;
import java.util.ArrayList;

public class AppVehiculos {
    public static void main(String[] args) {
        ArrayList<Vehiculo> vehiculos = new ArrayList<>();

        try {
            // Crear instancias de diferentes vehículos
            vehiculos.add(new Coche("Toyota", "Corolla", 2022, 180));
            vehiculos.add(new Moto("Honda", "CBR600", 2021, 250));
            vehiculos.add(new Bicicleta("Trek", "Marlin 5", 2023, 40));
            vehiculos.add(new Camion("Volvo", "FH16", 2020, 120));
            vehiculos.add(new Patinete("Xiaomi", "Mi Scooter 3", 2023, 25));
            
            // Intentar crear un vehículo con velocidad inválida (debería lanzar excepción)
            // vehiculos.add(new Coche("Ferrari", "Testarossa", 2023, -300));
        } catch (VelocidadInvalidaException e) {
            System.err.println("Error al crear vehículo: " + e.getMessage());
        }

        // Recorrer la lista y mostrar información de cada vehículo
        for (Vehiculo vehiculo : vehiculos) {
            System.out.println("\n" + vehiculo);
            vehiculo.arrancar(); // Polimorfismo en acción
        }
    }
}